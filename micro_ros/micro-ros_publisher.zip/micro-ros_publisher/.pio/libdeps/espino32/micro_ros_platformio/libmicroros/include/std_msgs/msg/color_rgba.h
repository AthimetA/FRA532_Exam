// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_msgs:msg/ColorRGBA.idl
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__COLOR_RGBA_H_
#define STD_MSGS__MSG__COLOR_RGBA_H_

#include "std_msgs/msg/detail/color_rgba__struct.h"
#include "std_msgs/msg/detail/color_rgba__functions.h"
#include "std_msgs/msg/detail/color_rgba__type_support.h"

#endif  // STD_MSGS__MSG__COLOR_RGBA_H_
