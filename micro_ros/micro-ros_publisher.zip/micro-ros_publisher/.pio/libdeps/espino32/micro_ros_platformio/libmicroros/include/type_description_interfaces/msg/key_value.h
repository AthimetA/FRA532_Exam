// generated from rosidl_generator_c/resource/idl.h.em
// with input from type_description_interfaces:msg/KeyValue.idl
// generated code does not contain a copyright notice

#ifndef TYPE_DESCRIPTION_INTERFACES__MSG__KEY_VALUE_H_
#define TYPE_DESCRIPTION_INTERFACES__MSG__KEY_VALUE_H_

#include "type_description_interfaces/msg/detail/key_value__struct.h"
#include "type_description_interfaces/msg/detail/key_value__functions.h"
#include "type_description_interfaces/msg/detail/key_value__type_support.h"

#endif  // TYPE_DESCRIPTION_INTERFACES__MSG__KEY_VALUE_H_
