// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_msgs:msg/Int64.idl
// generated code does not contain a copyright notice

#ifndef STD_MSGS__MSG__INT64_H_
#define STD_MSGS__MSG__INT64_H_

#include "std_msgs/msg/detail/int64__struct.h"
#include "std_msgs/msg/detail/int64__functions.h"
#include "std_msgs/msg/detail/int64__type_support.h"

#endif  // STD_MSGS__MSG__INT64_H_
