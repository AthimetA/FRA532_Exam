// generated from rosidl_generator_c/resource/idl.h.em
// with input from stereo_msgs:msg/DisparityImage.idl
// generated code does not contain a copyright notice

#ifndef STEREO_MSGS__MSG__DISPARITY_IMAGE_H_
#define STEREO_MSGS__MSG__DISPARITY_IMAGE_H_

#include "stereo_msgs/msg/detail/disparity_image__struct.h"
#include "stereo_msgs/msg/detail/disparity_image__functions.h"
#include "stereo_msgs/msg/detail/disparity_image__type_support.h"

#endif  // STEREO_MSGS__MSG__DISPARITY_IMAGE_H_
